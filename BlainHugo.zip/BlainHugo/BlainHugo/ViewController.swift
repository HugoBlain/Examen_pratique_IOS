//
//  ViewController.swift
//  BlainHugo
//
//  Created by Hugo Blain on 02/02/2021.
//
// question 1: faite
// question 2: faite
// question 3: faite
// question 4: faite
// question 5: faite


import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    // données de http://ginhac.com/data-people.html
    let fullnames = [ "Felisha Toal", "Katharina Pauly", "Vella Vanauken", "Pauletta Thelen", "Kandace Eguia", "Howard Krikorian", "Toby Caya", "Ed Abbott", "Alena Grund", "Dorcas Durazo", "Clora Thurston", "Lekisha Musich", "Harriette Tuten", "Yolanda Will", "Lasonya Mccaffery", "Tracee Fulks", "Antionette Tews", "Latia Wheatley", "Neta Kelton", "Elaine Clark" ]
    let ages = [20, 44, 34, 17, 78, 56, 49, 40, 12, 45, 67, 90, 53, 92, 08, 34, 29, 39, 10, 45]


    // tableau de personne (vide à l'origine)
    var mesPersonnes: [People] = []
    
    // attributs du viewController
    // variable qui sert à savoir dans quel ordre trier les ages
    var croissant: Bool = true
    
    
    // les outlets
    @IBOutlet weak var monTableView: UITableView!
    @IBOutlet weak var croissantOuPas: UILabel!
    
    // les actions
    @IBAction func trierClick(_ sender: Any) {
        if croissant {
            mesPersonnes.sort(by: {$0.age < $1.age })
        }
        else {
            mesPersonnes.sort(by: {$0.age > $1.age })
        }
        monTableView.reloadData()
    }
    @IBAction func switchChangement(_ sender: UISwitch) {
        if sender.isOn == true {
            croissantOuPas.text = "croissant"
            croissant = true
        }
        else {
            croissantOuPas.text = "décroissant"
            croissant = false
        }
    }
    
    
    
    // #### fonctions associées au protocol UITableViewDataSource ####
    // nombre de ligne du tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mesPersonnes.count
    }
    // remplissage des cellules du tableView
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellule = monTableView.dequeueReusableCell(withIdentifier: "personneCell", for: indexPath) as! PersonneTableViewCell
        let ligne = indexPath.row
        cellule.nomPrenom.text = mesPersonnes[ligne].nom
        cellule.age.text = String(mesPersonnes[ligne].age)
        return cellule
    }
    
    
    
    // fonction au lancement
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // on instancie autant de personne qu'il y en a dans les données récupèrées
        for i in 0...fullnames.count-1 {
            let nouvellePersonne = People(nom: fullnames[i], age: ages[i])
            mesPersonnes.append(nouvellePersonne)
            print("Nouvelle personne: "+nouvellePersonne.nom+", "+String(nouvellePersonne.age)+" ans")
        }
        
        // pour le protocol UITableViewDataSource
        monTableView.dataSource = self
        
    }


}

