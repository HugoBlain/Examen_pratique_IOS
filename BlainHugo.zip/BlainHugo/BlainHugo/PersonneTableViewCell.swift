//
//  personneTableViewCell.swift
//  BlainHugo
//
//  Created by Hugo Blain on 02/02/2021.
//

import UIKit


// classe pour les cellules de notre tableView
class PersonneTableViewCell: UITableViewCell {

    // les outlets
    @IBOutlet weak var nomPrenom: UILabel!
    @IBOutlet weak var age: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
