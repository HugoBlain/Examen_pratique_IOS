//
//  People.swift
//  BlainHugo
//
//  Created by Hugo Blain on 02/02/2021.
//

import Foundation

// classe contenant l'age et le nom d'une personne
class People {
    
    // attributs
    let nom: String
    var age: Int
    
    // constructeur
    init(nom: String, age: Int) {
        self.nom = nom
        self.age = age
    }
    
    
}
